#!/usr/bin/env python
# coding:utf-8
#   |                                                         |   #
# --+---------------------------------------------------------+-- #
#   |    Code by: yasserbdj96                                 |   #
#   |    Email: yasser.bdj96@gmail.com                        |   #
#   |    GitHub: github.com/yasserbdj96                       |   #
#   |    Sponsor: github.com/sponsors/yasserbdj96             |   #
#   |    BTC: bc1q2dks8w8uurca5xmfwv4jwl7upehyjjakr3xga9      |   #
#   |                                                         |   #
#   |    All posts with #yasserbdj96                          |   #
#   |    All views are my own.                                |   #
# --+---------------------------------------------------------+-- #
#   |                                                         |   #

#START{
errx="[✗]"
emsg_1=f"{errx} We were unable to recognize the hiphp identifier."
emsg_2=f"{errx} Command not found!"
emsg_3=f"{errx} We could not contact the site"
emsg_4=f"{errx} The file you entered does not exist."
emsg_5=f"{errx} We could not upload the file"
emsg_6=": Command does not exist or ended with a server error."

msgi="[!]"
msg_1=f"{msgi} Copy the PHP code below to the website path you entered:"
msg_2=f"{msgi} There is a new update "
msg_3=f"{msgi} Download the new version from 'https://github.com/yasserbdj96/hiphp'"
msg_4=f"{msgi} No updates available"

msgs="[✓]"
smsg_1=f"{msgs} File downloaded in: "
smsg_2=f"{msgs} The path has been compressed into: "
#}END.