<h2>Run Hiphp-desktop:</h2>

```bash
# Download hiphp from github:
❯ git clone https://github.com/yasserbdj96/hiphp.git
# OR
# Download hiphp from gitlab:
❯ git clone https://gitlab.com/yasserbdj96/hiphp.git

# Go to downloaded folder:
❯ cd hiphp

# install requirements:
❯ pip install -r requirements.txt
❯ pip install -r hiphp-linux/requirements-linux.txt #for linux os.
❯ pip install -r hiphp-win/requirements-win.txt #for windows os.

# run with hiphp-desktop tool:
❯ python main.py --DST

# Run with Makefile:
❯ make ARGUMENTS="--DST" run
# Open your web browser and navigate to http://127.0.0.1:8080 to see the default landing page.

# For Linux:
❯ cd hiphp-linux
❯ bash hiphp-desktop.sh
# Open your web browser and navigate to http://127.0.0.1:8080 to see the default landing page.

# For Windows:
# Do not forget to modify the "config.ini" file or use the following command:
# > python -c "import sys; open('config.ini','w+').write('python_default_path='+sys.executable)"
# OR Run 'hiphp-win\config-configure.py'.
❯ cd hiphp-win
❯ hiphp-desktop.bat
# Open your web browser and navigate to http://127.0.0.1:8080 to see the default landing page.

```

<br>
<h4>Run hiphp-desktop In Colab:</h4>
<a target="_blank" href="https://colab.research.google.com/github/yasserbdj96/hiphp/blob/main/hiphp.ipynb">Open hiphp-desktop In Colab</a>

<br>
<h2>Screenshots:</h2>

<div align="center">
    </a>
    <a href="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot5.png">
        <img height="100" src="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot5.png" alt="hhiphp-desktop login">
    </a>
    <a href="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot6.png">
        <img height="100" src="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot6.png" alt="hiphp-desktop">
    </a>
    <a href="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot7.png">
        <img height="100" src="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot7.png" alt="hiphp-desktop editor">
    </a>
    <a href="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot8.png">
        <img height="100" src="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot8.png" alt="hiphp-desktop login dark mode">
    </a>
    <a href="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot9.png">
        <img height="100" src="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot9.png" alt="hiphp-desktop dark mode">
    </a>
    <a href="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot10.png">
        <img height="100" src="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot10.png" alt="hiphp-desktop editor dark mode">
    </a>
    <a href="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot11.png">
        <img height="100" src="https://raw.githubusercontent.com/yasserbdj96/hiphp/main/screenshot/screenshot11.png" alt="hiphp-desktop settings">
    </a>
</div>

<br>
<h2>Changelog History:</h2>

<details>
  <summary>Click to See changelog History</summary>

```
## 0.2.2 [18-11-2022][Last Version]
 - Bug fixes & performance improvements.
```

</details>